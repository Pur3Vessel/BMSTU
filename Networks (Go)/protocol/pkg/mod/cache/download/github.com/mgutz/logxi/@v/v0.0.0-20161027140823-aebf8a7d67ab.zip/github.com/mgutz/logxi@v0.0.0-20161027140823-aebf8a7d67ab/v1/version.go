package log

// Version is the version of this package
const Version = "1.0.0-pre"
