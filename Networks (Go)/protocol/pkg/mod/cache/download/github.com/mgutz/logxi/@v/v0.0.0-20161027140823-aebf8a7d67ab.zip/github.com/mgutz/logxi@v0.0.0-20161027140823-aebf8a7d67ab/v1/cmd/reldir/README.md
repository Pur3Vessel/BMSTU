# reldir

Used to test relative paths when logging context.
